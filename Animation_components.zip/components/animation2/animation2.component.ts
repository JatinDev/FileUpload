import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';

@Component({
  selector: 'app-animation2',
  templateUrl: './animation2.component.html',
  styleUrls: ['./animation2.component.css']
})
export class Animation2Component implements OnInit {

  @ViewChild('myCanvas') myCanvas: ElementRef<HTMLCanvasElement>;
  context: CanvasRenderingContext2D;
  noGenerated: number;
  obj = [
    { key: 'ArrowUp', value: 0 },
    { key: 'ArrowRight', value: 90 },
    { key: 'ArrowDown', value: 180 },
    { key: 'ArrowLeft', value: 270 }
  ];
  color: boolean;

  constructor() { }

  ngOnInit(): void {
    this.GenerateRandomNoAndDraw();
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (this.obj[this.noGenerated].key === event.key) {
      this.GenerateRandomNoAndDraw();
      this.color = !this.color;
    }
  }

  CanvasClick(e) {
    console.log(e);
  }

  DrawImage(pos: number) {
    setTimeout(() => {
      this.context = this.myCanvas.nativeElement.getContext('2d');
      this.context.fillStyle = this.color ? 'red' : 'blue';
      this.context.fillRect(0, 0, 600, 400);

      this.context.translate(300, 200);
      this.context.rotate((Math.PI / 180) * pos);

      this.context.fillStyle = !this.color ? 'red' : 'blue';;
      this.context.beginPath();     
      this.context.moveTo(0, 0);
      this.context.lineTo(-10, 10);
      this.context.lineTo(10, 10);
      this.context.fill();
      this.context.fillRect(-2, 10, 4, 10);
      this.context.rotate(-(Math.PI / 180) * pos);

      this.context.translate(-300, -200);      

    });
  }

  GenerateRandomNoAndDraw() {
    this.noGenerated = this.randomIntFromInterval(0, 3);
    this.DrawImage(this.obj[this.noGenerated].value);
  }

  randomIntFromInterval(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}
