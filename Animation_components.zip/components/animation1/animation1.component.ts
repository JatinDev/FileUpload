import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-animation1',
  templateUrl: './animation1.component.html',
  styleUrls: ['./animation1.component.css']
})
export class Animation1Component implements OnInit, AfterViewInit {

  @ViewChild('myCanvas') myCanvas: ElementRef<HTMLCanvasElement>;
  context: CanvasRenderingContext2D;
  alphabets = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
    'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  alphaToRead = this.alphabets[this.randomIntFromInterval(0, 25)];
  counter = 0;
  alphaArrayOnView = [];

  constructor() { }

  ngOnInit(): void {

  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.context = this.myCanvas.nativeElement.getContext('2d');
      this.context.strokeStyle = 'red';
      this.context.font = '12px serif';
      for (let j = 0; j < 10; j++) {
        for (let i = 0; i < 15; i++) {
          let txt = this.alphabets[this.randomIntFromInterval(0, 25)];
          if (this.alphaToRead === txt)
            this.counter++;
          this.context.strokeRect(i * 40, j * 40, 40, 40);
          this.context.fillText(txt, 15 + i * 40, 20 + j * 40);
          this.alphaArrayOnView.push(txt);
        }
      }
    });
  }

  randomIntFromInterval(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  CanvasClick(e) {
    let col = Math.ceil(e.layerX / 40);
    let row = Math.ceil(e.layerY / 40)
    let box = (row - 1) * 15 + col;
    if (this.alphaToRead === this.alphaArrayOnView[box - 1]) {
      this.alphaArrayOnView[box - 1] = '';
      this.counter--;      
      let boxX = e.layerX < 41 ? 0 : e.layerX;
      let boxY = e.layerY < 41 ? 0 : e.layerY;
      for (let i = e.layerX; i > 0; i--) {
        if (i % 40 == 0) {
          boxX = i;
          break
        }
      }
      for (let j = e.layerY; j > 0; j--) {
        if (j % 40 == 0) {
          boxY = j;
          break
        }
      }
      this.context.clearRect(boxX + 5, boxY + 5, 30, 30);
    }  
  }
}
