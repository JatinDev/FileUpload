import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';

@Component({
  selector: 'app-animation3',
  templateUrl: './animation3.component.html',
  styleUrls: ['./animation3.component.css']
})
export class Animation3Component implements OnInit {

  @ViewChild('myCanvas') myCanvas: ElementRef<HTMLCanvasElement>;
  context: CanvasRenderingContext2D;

  constructor() { }
  obj = [
    { key: 'ArrowRight', value: 0, x: 0, y: 0 },
    { key: 'ArrowDown', value: 90, x: -20, y: 0 },
    { key: 'ArrowLeft', value: 180, x: -20, y: 20 },
    { key: 'ArrowUp', value: 270, x: 0, y: 20 },
  ];
  noGenerated: number;

  ngOnInit(): void {
    this.GenerateRandomNoAndDraw();
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (this.obj[this.noGenerated].key === event.key) {
      this.GenerateRandomNoAndDraw();
    }
  }

  CanvasClick(e) {
  }

  DrawImage(pos) {
    setTimeout(() => {
      this.context = this.myCanvas.nativeElement.getContext('2d');
      this.context.clearRect(0, 0, this.myCanvas.nativeElement.width, this.myCanvas.nativeElement.height);
      let x = this.myCanvas.nativeElement.width / 2;
      let y = this.myCanvas.nativeElement.height / 2;
      this.context.translate(x, y);
      this.context.rotate((Math.PI / 180) * pos);
      this.context.font = "40px Verdana"
      this.context.strokeText('E', this.obj[this.noGenerated].x, this.obj[this.noGenerated].y);

      this.context.rotate(-(Math.PI / 180) * pos);
      this.context.translate(-x, -y);
    });
  }

  GenerateRandomNoAndDraw() {
    let temp = this.randomIntFromInterval(0, 3);
    if (this.noGenerated == temp)
      for (let i = 0; i < 4; i++) {
        if (this.noGenerated == temp)
          temp = this.randomIntFromInterval(0, 3);
        else break;
      }
    this.noGenerated = temp;
    console.log(this.noGenerated);
    this.DrawImage(this.obj[this.noGenerated].value);
  }


  randomIntFromInterval(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}
