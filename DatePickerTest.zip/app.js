var app = angular.module('myApp', ['ngMaterialDatePicker']);
app.controller('FirstController', function ($scope) {
    $scope.message = 'Hello from FirstController';
});