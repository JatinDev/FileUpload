import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { MatSliderModule } from '@angular/material/slider';

@NgModule({
    imports: [
        MatSelectModule,
        MatSliderModule
    ],
    exports: [
        MatSelectModule,
        MatSliderModule
    ]
})
export class AppMaterialModule { }


