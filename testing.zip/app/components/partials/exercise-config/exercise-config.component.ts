import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ExerciseConfig } from 'src/app/models/exercise-config';

@Component({
  selector: 'app-exercise-config',
  templateUrl: './exercise-config.component.html',
  styleUrls: ['./exercise-config.component.css']
})
export class ExerciseConfigComponent implements OnInit {

  constructor() { }

  maxDurationTime = 30;
  durationList: number[] = [];
  fontList: number[] = [];
  redColorLightness: string[] = [];
  blueColorLightness: string[] = [];
  selectedBlue: string;
  selectedRed: string;
  exerciseConfig: ExerciseConfig;
  @Output() dataFromConfig = new EventEmitter<ExerciseConfig>();

  ngOnInit(): void {
    for (let i = 1; i <= this.maxDurationTime; i++) {
      this.durationList.push(i);
      if (i > 7)
        this.fontList.push(i);
    }

    for (let i = 3; i < 16; i++) {
      this.redColorLightness.push(this.HSLToHex(0, 100, i * 5));
      this.blueColorLightness.push(this.HSLToHex(240, 100, i * 5));
    }

    this.exerciseConfig = {
      duration: this.durationList[0],
      fontSize: this.fontList[0],
      redColor: '',
      blueColor: ''

    };

    this.redColorLightness.reverse();
    this.blueColorLightness.reverse();
    this.exerciseConfig.redColor = this.redColorLightness[0];
    this.exerciseConfig.blueColor = this.blueColorLightness[0];
  }

  SliderChange(type: number, sliderObj: any) {
    switch (type) {
      case 0:
        this.exerciseConfig.blueColor = this.blueColorLightness[sliderObj.value];
        break;
      case 1:
        this.exerciseConfig.redColor = this.redColorLightness[sliderObj.value];
        break;
      default:
        break;
    }

  }

  HSLToHex(h, s, l): string {
    s /= 100;
    l /= 100;

    let c = (1 - Math.abs(2 * l - 1)) * s,
      x = c * (1 - Math.abs((h / 60) % 2 - 1)),
      m = l - c / 2,
      r = 0,
      g = 0,
      b = 0;

    if (0 <= h && h < 60) {
      r = c; g = x; b = 0;
    } else if (60 <= h && h < 120) {
      r = x; g = c; b = 0;
    } else if (120 <= h && h < 180) {
      r = 0; g = c; b = x;
    } else if (180 <= h && h < 240) {
      r = 0; g = x; b = c;
    } else if (240 <= h && h < 300) {
      r = x; g = 0; b = c;
    } else if (300 <= h && h < 360) {
      r = c; g = 0; b = x;
    }
    // Having obtained RGB, convert channels to hex
    let fr = Math.round((r + m) * 255).toString(16);
    let fg = Math.round((g + m) * 255).toString(16);
    let fb = Math.round((b + m) * 255).toString(16);

    // Prepend 0s, if necessary
    if (fr.length == 1)
      fr = "0" + fr;
    if (fg.length == 1)
      fg = "0" + fg;
    if (fb.length == 1)
      fb = "0" + b;

    return "#" + fr + fg + fb;
  }

  StartExercie() {
    this.exerciseConfig.duration = this.exerciseConfig.duration * 60;
    this.dataFromConfig.emit(this.exerciseConfig);
  }
}
