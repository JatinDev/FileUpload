import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {

  constructor() { }
  @Input() TotalSec: number;
  min: string = '0';
  sec: string = '0';
  interval: any;
  @Output() isComplete = new EventEmitter<boolean>();

  ngOnInit(): void {
    this.setMinSec();
    this.StartTimer();
  }

  StartTimer() {
    this.interval = setInterval(() => {
      if (this.TotalSec >= 0) {
        this.setMinSec();
        this.TotalSec--;
      }
      else {
        this.isComplete.emit(true);
        clearInterval(this.interval);
      }
    }, 1000);
  }

  setMinSec() {
    this.min = Math.floor(this.TotalSec % 3600 / 60).toString();
    this.sec = Math.floor(this.TotalSec % 3600 % 60).toString();
    this.min = Number(this.min) < 10 ? '0' + this.min : this.min;
    this.sec = Number(this.sec) < 10 ? '0' + this.sec : this.sec;
  }

}
