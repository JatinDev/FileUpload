import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { ExerciseConfig } from 'src/app/models/exercise-config';

@Component({
  selector: 'app-animation4',
  templateUrl: './animation4.component.html',
  styleUrls: ['./animation4.component.css']
})
export class Animation4Component implements OnInit {

  @ViewChild('myCanvas') myCanvas: ElementRef<HTMLCanvasElement>;
  context: CanvasRenderingContext2D;
  obj = [
    { key: 'ArrowRight', value: 0, x: 0, y: 0 },
    { key: 'ArrowDown', value: 90, x: 0, y: 0 },
    { key: 'ArrowLeft', value: 180, x: 0, y: 0 },
    { key: 'ArrowUp', value: 270, x: 0, y: 0 }
  ];
  color: boolean;
  generatedLetters: number[] = [];
  isConfigSet: boolean;
  config: ExerciseConfig;

  constructor() { }

  ngOnInit(): void {
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (this.obj[this.generatedLetters[0]].key === event.key) {
      this.generatedLetters.splice(0, 1);
      this.RemoveLetter();
    }
  }

  draw() {
    this.context.save();
    this.context.fillStyle = 'black';
    this.context.fillRect(0, 0, 600, 400);


    // this.context.strokeStyle = "white";
    // this.context.moveTo(0, 200);
    // this.context.lineTo(600, 200);
    // this.context.moveTo(150, 0);
    // this.context.lineTo(150, 600);
    // this.context.moveTo(250, 0);
    // this.context.lineTo(250, 600);
    // this.context.moveTo(350, 0);
    // this.context.lineTo(350, 600);
    // this.context.moveTo(450, 0);
    // this.context.lineTo(450, 600);
    // this.context.stroke();

    this.context.font = (this.config.fontSize * 2).toString() + "px Verdana";
    this.context.translate(150, 200);
    for (let i = 0; i < 4; i++) {
      let randomNo = this.randomIntFromInterval(0, 3);
      this.context.translate(i * 100, 0);
      this.context.rotate((Math.PI / 180) * this.obj[randomNo].value);
      this.context.fillStyle = this.color ? this.config.redColor : this.config.blueColor;
      this.context.fillText('C', this.obj[randomNo].x, this.obj[randomNo].y);
      this.context.rotate(-(Math.PI / 180) * this.obj[randomNo].value);
      this.context.translate(-i * 100, 0);
      this.generatedLetters.push(randomNo);
    }
  }

  randomIntFromInterval(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  RemoveLetter() {
    for (let i = 0; i < 4 - this.generatedLetters.length; i++) {
      this.context.fillStyle = 'black';
      this.context.fillRect(i * 100, 160, 50, 50);
    }
    if (this.generatedLetters.length === 0) {
      this.color = !this.color;
      this.context.restore();
      this.draw();
    }
  }

  dataFromConfig(data: ExerciseConfig) {
    this.config = data;
    if (data) this.isConfigSet = true;
    this.obj[0].x = -this.config.fontSize / 3;
    // this.obj[0].y = this.config.fontSize / 2;
    this.obj[1].x = -this.config.fontSize / 3;
    // this.obj[1].y = this.config.fontSize;
    this.obj[2].x = -this.config.fontSize / 3;
    // this.obj[2].y = this.config.fontSize;
    this.obj[3].x = -this.config.fontSize / 3;
    // this.obj[3].y = this.config.fontSize;
    setTimeout(() => {
      this.context = this.myCanvas.nativeElement.getContext('2d');
      this.context.textBaseline = "middle";
      this.draw();
    }, 0);
  }
}
