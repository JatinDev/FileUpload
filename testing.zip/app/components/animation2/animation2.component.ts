import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { ExerciseConfig } from 'src/app/models/exercise-config';

@Component({
  selector: 'app-animation2',
  templateUrl: './animation2.component.html',
  styleUrls: ['./animation2.component.css']
})
export class Animation2Component implements OnInit {

  @ViewChild('myCanvas') myCanvas: ElementRef<HTMLCanvasElement>;
  context: CanvasRenderingContext2D;
  noGenerated: number;
  obj = [
    { key: 'ArrowUp', value: 0 },
    { key: 'ArrowRight', value: 90 },
    { key: 'ArrowDown', value: 180 },
    { key: 'ArrowLeft', value: 270 }
  ];
  color: boolean;
  isConfigSet: boolean;
  config: ExerciseConfig;

  constructor() { }

  ngOnInit(): void {

  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (this.obj[this.noGenerated].key === event.key) {
      this.GenerateRandomNoAndDraw();
      this.color = !this.color;
    }
  }

  CanvasClick(e) {
    console.log(e);
  }

  DrawImage(pos: number) {
    setTimeout(() => {
      let randomX = this.randomIntFromInterval(40, 560);
      let randomY = this.randomIntFromInterval(40, 360);
      this.context = this.myCanvas.nativeElement.getContext('2d');
      this.context.fillStyle = this.color ? this.config.redColor : this.config.blueColor;
      this.context.fillRect(0, 0, 600, 400);

      this.context.translate(randomX, randomY);
      this.context.rotate((Math.PI / 180) * pos);

      this.context.fillStyle = !this.color ? this.config.redColor : this.config.blueColor;
      this.context.beginPath();
      this.context.moveTo(0, 0);
      this.context.lineTo(-this.config.fontSize, this.config.fontSize);
      this.context.lineTo(this.config.fontSize, this.config.fontSize);
      this.context.fill();
      this.context.fillRect(-this.config.fontSize / 5, this.config.fontSize, this.config.fontSize / 2.5, this.config.fontSize);
      this.context.rotate(-(Math.PI / 180) * pos);
      this.context.translate(-randomX, -randomY);

    });
  }

  GenerateRandomNoAndDraw() {
    this.noGenerated = this.randomIntFromInterval(0, 3);
    this.DrawImage(this.obj[this.noGenerated].value);
  }

  randomIntFromInterval(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  dataFromConfig(data: ExerciseConfig) {
    this.config = data;
    if (data) this.isConfigSet = true;
    this.GenerateRandomNoAndDraw();
  }

  Completed(value: boolean) {
    if (value)
      alert('you have completed this exercise. Thank you');
  }
}
