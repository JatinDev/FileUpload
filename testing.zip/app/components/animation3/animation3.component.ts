import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { ExerciseConfig } from 'src/app/models/exercise-config';

@Component({
  selector: 'app-animation3',
  templateUrl: './animation3.component.html',
  styleUrls: ['./animation3.component.css']
})
export class Animation3Component implements OnInit {

  @ViewChild('myCanvas') myCanvas: ElementRef<HTMLCanvasElement>;
  context: CanvasRenderingContext2D;

  constructor() { }
  obj = [
    { key: 'ArrowRight', value: 0, x: 0, y: 0 },
    { key: 'ArrowDown', value: 90, x: -20, y: 0 },
    { key: 'ArrowLeft', value: 180, x: -20, y: 20 },
    { key: 'ArrowUp', value: 270, x: 0, y: 20 },
  ];
  noGenerated: number;
  isConfigSet: boolean;
  config: ExerciseConfig;
  color: boolean;

  ngOnInit(): void {
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (this.obj[this.noGenerated].key === event.key) {
      this.color = !this.color;
      this.GenerateRandomNoAndDraw();
    }
  }

  CanvasClick(e) {
  }

  DrawImage(pos) {
    setTimeout(() => {
      let randomX = this.randomIntFromInterval(40, 560);
      let randomY = this.randomIntFromInterval(40, 360);
      this.context = this.myCanvas.nativeElement.getContext('2d');
      this.context.clearRect(0, 0, this.myCanvas.nativeElement.width, this.myCanvas.nativeElement.height);
      this.context.translate(randomX, randomY);
      this.context.rotate((Math.PI / 180) * pos);
      this.context.font = (this.config.fontSize * 2).toString() + "px Verdana";
      this.context.fillStyle = this.color ? this.config.redColor : this.config.blueColor
      this.context.fillText('E', 0, 0);

      this.context.rotate(-(Math.PI / 180) * pos);
      this.context.translate(-randomX, -randomY);
    });
  }

  dataFromConfig(data: ExerciseConfig) {
    this.config = data;
    if (data) this.isConfigSet = true;
    this.GenerateRandomNoAndDraw();
  }

  GenerateRandomNoAndDraw() {
    let temp = this.randomIntFromInterval(0, 3);
    if (this.noGenerated == temp)
      for (let i = 0; i < 4; i++) {
        if (this.noGenerated == temp)
          temp = this.randomIntFromInterval(0, 3);
        else break;
      }
    this.noGenerated = temp;
    console.log(this.noGenerated);
    this.DrawImage(this.obj[this.noGenerated].value);
  }

  Completed(value: boolean) {
    if (value)
      alert('you have completed this exercise. Thank you');
  }

  randomIntFromInterval(min, max): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}
