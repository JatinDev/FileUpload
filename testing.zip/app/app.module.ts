import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Animation1Component } from './components/animation1/animation1.component';
import { Animation2Component } from './components/animation2/animation2.component';
import { Animation3Component } from './components/animation3/animation3.component';
import { Animation4Component } from './components/animation4/animation4.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ExerciseConfigComponent } from './components/partials/exercise-config/exercise-config.component';
import { AppMaterialModule } from './app.material.module';
import { FormsModule } from '@angular/forms';
import { TimerComponent } from './components/partials/timer/timer.component';

@NgModule({
  declarations: [
    AppComponent,
    Animation1Component,
    Animation2Component,
    Animation3Component,
    Animation4Component,
    ExerciseConfigComponent,
    TimerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    AppMaterialModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
