export interface ExerciseConfig {
    duration: number,
    fontSize?: number,
    blueColor: string,
    redColor: string
}