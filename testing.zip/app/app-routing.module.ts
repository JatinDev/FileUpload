import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Animation1Component } from './components/animation1/animation1.component';
import { Animation2Component } from './components/animation2/animation2.component';
import { Animation3Component } from './components/animation3/animation3.component';
import { Animation4Component } from './components/animation4/animation4.component';
import { ExerciseConfigComponent } from './components/partials/exercise-config/exercise-config.component';
import { TimerComponent } from './components/partials/timer/timer.component';


const routes: Routes = [
  { path: 'anime1', component: Animation1Component },
  { path: 'anime2', component: Animation2Component },
  { path: 'anime3', component: Animation3Component },
  { path: 'anime4', component: Animation4Component },
  { path: 'partial1', component: ExerciseConfigComponent },
  { path: 'partial2', component: TimerComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
